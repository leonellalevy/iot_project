# iot_project
This is a team project in IoT course.
